# Pattern catalogue

Generated from assets/patterns.pptx by `inventory.py --catalogue`. Do not edit by hand: change the
pattern slide's speaker notes (PATTERN / PURPOSE / USE WHEN / ITEMS) and regenerate.

Slots: fill these keys in plan.json. `~Nw` is a rough capacity in words at the template font size,
and the quoted text is what a human wrote there originally: match its length and kind, never copy it.
Item slots (`itemN_...`) can be left out from the end: unused items are removed with their shapes.
Tables (`t1`, `t2`) take a list of rows, header row first; rows you do not give are removed.

## TITLE
- **Purpose:** Cover slide
- **Use When:** First slide of every deck
- **Slots:** `title` (~12w), `subtitle` (~25w), `date` (~11w)

## SECTION
- **Purpose:** Section divider
- **Use When:** Start of each major section (3-6 per deck)
- **Slots:** `section_number` (~1w), `section_title` (~10w)

## OBJ_3COL
- **Purpose:** Three objectives or themes side by side, each with an icon
- **Use When:** Objectives, key themes, pillars when there are exactly 2-3 parallel ideas
- **Items:** 2-3
- **Slots:** `title` (~24w), `tracker` (~18w), `item1_head` (~9w), `item1_body` (~80w), `item2_head` (~9w), `item2_body` (~80w), `item3_head` (~9w), `item3_body` (~80w), `source` (~26w)
- **Icons:** `item1_icon`, `item2_icon`, `item3_icon`

## OBJ_NUMBERED_4
- **Purpose:** Numbered list of objectives or priorities with a short explanation each
- **Use When:** Objectives or priorities when there are 3-4 items needing a sentence each
- **Items:** 3-4
- **Slots:** `title` (~24w), `tracker` (~18w), `item1_head` (~17w), `item1_body` (~58w), `item2_head` (~17w), `item2_body` (~58w), `item3_head` (~17w), `item3_body` (~58w), `item4_head` (~17w), `item4_body` (~58w), `source` (~26w)

## APPROACH_CHEVRON_4
- **Purpose:** Phased approach, left to right, with activities under each phase
- **Use When:** Approach, methodology or roadmap with 3-4 sequential phases
- **Items:** 3-4
- **Slots:** `title` (~24w), `tracker` (~18w), `item1_phase` (~15w), `item1_time` (~6w), `item1_body` (~85w), `item2_phase` (~15w), `item2_time` (~6w), `item2_body` (~85w), `item3_phase` (~15w), `item3_time` (~6w), `item3_body` (~85w), `item4_phase` (~15w), `item4_time` (~6w), `item4_body` (~85w), `source` (~26w)

## TWO_COL
- **Purpose:** Two contrasting or complementary blocks
- **Use When:** Current vs future state, challenge vs response, what we heard vs what it means
- **Slots:** `title` (~24w), `tracker` (~18w), `left_head` (~8w), `left_body` (~189w), `right_head` (~8w), `right_body` (~189w), `source` (~26w)

## GOV_MATRIX
- **Purpose:** Matrix of activities against forums, owners or phases, with ticks
- **Use When:** Governance, RACI or activity-by-phase views with up to 6 rows and 3 columns
- **Slots:** `title` (~24w), `tracker` (~18w), `source` (~26w)
- **Table `t1`:** 7 rows x 4 columns

